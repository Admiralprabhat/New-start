//write a program in c to use ASCII characters to display letters respectively
#include <stdio.h>

int main() {
    // Declare a character variable 'ch' and assign it the value 'A'
    char ch = 'A';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch, ch);
    // Declare a character variable 'ch1' and assign it the value 'a'
    char ch1 = 'a';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch1, ch1);
    // Declare a character variable 'ch2' and assign it the value 'B'
    char ch2 = 'B';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch2, ch2);
    // Declare a character variable 'ch3' and assign it the value 'b'
    char ch3 = 'b';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch3, ch3);
    // Declare a character variable 'ch4' and assign it the value 'C'
    char ch4 = 'C';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch4, ch4);
    // Declare a character variable 'ch5' and assign it the value 'c'
    char ch5 = 'c';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch5, ch5);
    // Declare a character variable 'ch6' and assign it the value '5'
    char ch6 = '5';
    // Print the character and its corresponding ASCII value
    printf("The ASCII value of '%c' is %d\n", ch6, ch6);
    return 0;
}
